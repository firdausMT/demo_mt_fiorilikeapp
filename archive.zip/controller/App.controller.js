sap.ui.define(["mt/fin/ap/fk/controller/BaseController"],function(e){"use strict";return e.extend("mt.fin.ap.fk.controller.App",{})});
//# sourceMappingURL=App.controller.js.map