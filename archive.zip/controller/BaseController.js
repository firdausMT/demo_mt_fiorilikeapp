sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("mt.fin.ap.fk.controller.BaseController",{})});
//# sourceMappingURL=BaseController.js.map