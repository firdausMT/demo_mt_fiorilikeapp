sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function(Controller) {
    'use strict';
    return Controller.extend("mt.fin.ap.fk.controller.BaseController", {
       
    })
   
});
 