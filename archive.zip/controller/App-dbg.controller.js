sap.ui.define([
    "mt/fin/ap/fk/controller/BaseController"
], function(Controller) {
    'use strict';
    return Controller.extend("mt.fin.ap.fk.controller.App", {
       
    })
   
});